<?php 
$templateroot = "http://192.168.1.13/pws";
$alarmcountry = "UK";
$alarmregion = "013";
$regionalurl = "http://www.meteoalarm.eu/en_UK/0/0/UK013-London%20&%20South%20East.html";
$password    = "B0j0v1ha";
?>