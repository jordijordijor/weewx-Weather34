When contributing ideas and improvements it is important to crosscheck the suggested ideas in all metrics , many times I see ideas
not working across all possibilities. many issues can arise due to various hardware used, interval updates, cross metric useage where
perhaps celsius is used with non metric variables. Its not easy to capture them all and often what may work perfectly well for you
does NOT always work well for others.

So I ask kindly you to think outside your own enviroment and what would the outcome be if you
were positioned in a different climate region. examples you may reside in a climate that gets little rainfall or totally the opposite like a monsoon region or extreme high temperatures and low humidity or vice versa low temperature high humidity.

All constructive ideas are always considered and you may see an issue or forward an idea but it may take time to implement as it needs to be crossed checked. weather templates due to the nature of various hardware,metrics are not like your simple website , blogging templates they require a lot of focus on finer detail that may not always be available as the nature of our weather changes from day to day , month to month , for example you have an idea that is put together in your winter season but it is easy to overlook what the output may be in the warmer seasons ..

Ideas based on iframe scraping data from other websites will never be implemented ,these type of scripts if not structured right can have a large impact of the performance(loading) .Weather34 has avoided these since the beginning way back in 2015 .I know it is a personal thing and some may want to display animated charts scrapped from commercial or third party sites but if that third party site has downtime or performance issues that is carried over to your website performance .Any third party data used in the template is generated in the background via official API useage where it is permitted on agreement to use the
data .Third party scraping of graphics,maps,radars etc are not used based on above..Any API useage even official API methods always has the risk of downtime however the benefit of using the official API methods is normally downtime is minimal ..So in short no ideas based on scraping will be implemented ..However if you want to do this for your pesonal use there is no reason why you cant its your website,your domain and so on.



