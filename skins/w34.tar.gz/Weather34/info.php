<?php include('shared.php')?>

<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Weather34 HOME WEATHER STATION HARDWARE INFORMATION</title>
     
      <style>
.container .title-card,button,p{font-family:Helvetica,Arial,sans-serif}body{padding:0;margin:0;box-sizing:border-box;background:0;height:300px;font-family:Arial, Helvetica, sans-serif;line-height:16px;}
.container a{width:100%;color:#f8f8f8;text-decoration:none;font-weight:400}.container{width:600px;padding:10px;color:#aaa;margin:1em auto;overflow:hidden;background:rgba(41, 43, 46, 1.000);border:1px solid #777;-webkit-border-radius:4px;-moz-border-radius:4px;-o-border-radius:4px;-ms-border-radius:4px;border-radius:4px}.container img{width:600px;height:352px}
.weather34darkbrowser{position:relative;background:0;width:100%;max-height:30px;margin:auto;margin-top:-5px;margin-left:0;border-top-left-radius:5px;border-top-right-radius:5px;padding-top:45px;background-image:radial-gradient(circle,#EB7061 6px,transparent 8px),radial-gradient(circle,#F5D160 6px,transparent 8px),radial-gradient(circle,#81D982 6px,transparent 8px),radial-gradient(circle,rgba(97,106,114,1) 2px,transparent 2px),radial-gradient(circle,rgba(97,106,114,1) 2px,transparent 2px),radial-gradient(circle,rgba(97,106,114,1) 2px,transparent 2px),linear-gradient(to bottom,rgba(59,60,63,0.4) 40px,transparent 0);background-position:left top,left top,left top,right top,right top,right top,0 0;background-size:50px 45px,90px 45px,130px 45px,50px 30px,50px 45px,50px 60px,100%;background-repeat:no-repeat,no-repeat}.weather34darkbrowser[url]:after{content:attr(url);color:#aaa;font-size:14px;position:absolute;left:0;right:0;top:0;padding:2px 15px;margin:11px 50px 0 90px;border-radius:3px;background:rgba(97, 106, 114, 0.3);height:20px;box-sizing:border-box}
</style>
</head>
<body>
<div class="weather34darkbrowser" url="Weather34 HOME WEATHER STATION HARDWARE INFORMATION"></div> 
<div class="container">
<img src="img/weather34hardware.jpg?ver=5" width="790px" height="490px" alt="weather34 hardware" title="weather34 hardware">
</div>
</body></html>